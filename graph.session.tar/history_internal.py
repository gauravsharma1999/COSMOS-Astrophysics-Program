# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

##---(Thu Jul 21 11:13:01 2016)---
print 'text'
pwd()
pwd
import os
os.cwd()
os.getcwd()
imort random as rd
import numpy as np
from matplotlib import pyplot as plt
x_axis = np.arange(100)
x
x_axis
y_axis = np.exp(-1.0*x_axis)
y_axis
plt.plot(y_axis)
plt.show()
plt.plot(y_axis, '.')
plt.show()